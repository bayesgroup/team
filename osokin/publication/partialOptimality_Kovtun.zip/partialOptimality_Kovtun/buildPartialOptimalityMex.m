function buildPartialOptimalityMex
% mex command to build partialOptimalityMex

mex partialOptimalityMex.cpp -output partialOptimalityMex -largeArrayDims
